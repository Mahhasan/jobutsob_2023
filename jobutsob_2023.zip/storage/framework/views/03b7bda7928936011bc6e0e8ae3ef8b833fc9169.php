

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card" style="box-shadow: 0px 2px #3498db;">
                <div class="card-header" style="display: flex; justify-content: space-between;">
                    <p class="card-title text-info">Company Info [ Total Company:  <b class="text-warning"><?php echo e($count); ?></b> ]</p>
                    <p class="card-title"><a  href="<?php echo e(route('create_company')); ?>" style="text-decoration: none;"><i class="fa fa-plus"></i> Create New</a></p>
                </div>
                <div class="card-body">
                    <!-- <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?> -->
                    <div class="table-responsive">
                    <table width="100%" class="table table-striped table-bordered table-hover" id="jobseeker">
                        <thead>
                            <tr>
                                <th>Sl No.</th>
                                <th>Logo</th>
                                <th>Company</th>
                                <th>Contact Info</th>
                                <th>Location</th>
                               <!--  <th>Address</th>
                                <th>Email</th>
                                <th>Cell</th> -->
                            </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="odd gradeX">
                                <td><?php echo e(++$index); ?></td>
                                <td ><img class="img img-responsive p-3" width="125" 
                                src="/logo/<?php echo e($value->logo); ?>" alt="<?php echo e($value->logo); ?>">
                               
                                <td><?php echo e($value->name); ?></td>
                                <td><?php echo e($value->user->name); ?><br>
                                    <?php echo e($value->user->designation); ?><br>
                                    <i class="fa fa-phone" aria-hidden="true"></i><?php echo e($value->user->cell); ?><br>
                                    <i class="fa fa-envelope" aria-hidden="true"></i> <?php echo e($value->user->email); ?>

                                </td>
                                <td><?php echo e($value->location); ?></td>
                                <!-- <td><?php echo e($value->job_category); ?></td>
                                <td><?php echo e($value->address); ?></td>
                                <td><?php echo e($value->cell); ?></td>
                                <td><?php echo e($value->email); ?></td> -->
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\jobutsob_2023\resources\views/company_info.blade.php ENDPATH**/ ?>