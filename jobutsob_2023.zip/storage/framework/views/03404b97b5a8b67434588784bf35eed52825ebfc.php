

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
        
            <div class="card mb-3" style="box-shadow: 0px 2px #3498db;">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <h5 class="card-title">All Jobs</h5>
                        </div>
                        <div class="col-md-6">
                            <form action="<?php echo e(route('job.search')); ?>" method="GET">
                                <div class="row">
                                    <div class="col-md-5">
                                        <select name="company" id="input" class="form-control">
                                            <option value="0">Select Company</option>
                                            <?php $__currentLoopData = $search_jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($value->company); ?>">
                                                <?php echo e(\App\Models\Company::find($value->company)->name); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="col-md-5">
                                        <input type="text" name="title" class="form-control" placeholder="Search your favorite job">
                                    </div>
                                    <div class="col-md-2">
                                        <button class="btn btn-secondary" type="submit">Search</button>
                                    </div>   
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="col-md-6">
            <div class="card mb-3" style="box-shadow: 0px 2px #3498db;">
                <div class="row">
                    <div class="col-md-8">
                        <div class="card-body">
                            <h5 class="card-title">Job Title:<b> <?php echo e($value->title); ?></b></h5>
                            <p class="card-text">Company:<b> <?php echo e(\App\Models\Company::find($value->company)->name); ?></b></p>
                            <p>Last Date:<b> <?php echo e($value->last_date); ?></b></p>
                            <a style="text-align: right; color: white;" class="btn btn-primary " data-toggle="modal" data-target="#example<?php echo e($value->id); ?>">Job Details</a>
                            <a href="<?php echo e(route('details',$value->id)); ?>" class="btn btn-primary">Apply</a>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <img class="card-img-top mt-3 pr-3" src="/logo/<?php echo e(\App\Models\Company::find($value->company)->logo); ?>" alt="<?php echo e($value->title); ?> <?php echo e($value->company); ?>">
                    </div>
                </div>
            </div>
        </div>
        <!-- Modal -->
        <div class="modal fade" id="example<?php echo e($value->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                <div class="modal-header" style="border-bottom: 2px solid #3490dc;">
                        <h5 class="modal-title" style="color: #3490dc;" id="exampleModalLabel"><b>Job Description </b></h5><br>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <h5 class="card-title">Job Title:<b> <?php echo e($value->title); ?></b></h5>
                        <p class="card-text">Company:<b> <?php echo e(\App\Models\Company::find($value->company)->name); ?></b></p>
                        <p>Last Date:<b> <?php echo e($value->last_date); ?></b></p>
                        <p class="card-text">Short Description: <?php echo $value->short_description; ?></p>
                        <p class="card-text">Description:<?php echo $value->description; ?></p>
                    </div>
                    <div class="modal-footer" style="border-top: 1px solid rgb(52, 144, 220);">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <h1 class="center m-5" style="color: #bc1d1a !important;">No Job Found</h1>
        <?php endif; ?>
    
    </div>
    <div class="row p-4">
    <?php echo e($data->appends(request()->except('page'))->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\jobutsob_2023\resources\views/search.blade.php ENDPATH**/ ?>