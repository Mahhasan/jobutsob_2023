

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Employer Info</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <div class="table-responsive">
                    <table width="100%" class="table table-striped table-bordered table-hover" id="example">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Company</th>
                                <th>Person</th>
                                <th>Category</th>
                                <th>Address</th>
                                <th>Cell</th>
                                <th>Email</th>
                                <th>Skill</th>
                                <th>Task</th>
                                <th>Salary</th>
                                <th>Logo</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $employers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="odd gradeX">
                            
                                <td><?php echo e(++$index); ?></td>
                                <td><?php echo e($value->company_name); ?></td>
                                <td><?php echo e($value->person_name); ?></td>
                                <td><?php echo e($value->job_category); ?></td>
                                <td><?php echo e($value->address); ?></td>
                                <td><?php echo e($value->cell); ?></td>
                                <td><?php echo e($value->email); ?></td>
                                <td><?php echo e($value->skill); ?></td>
                                <td><?php echo e($value->task); ?></td>
                                <td><?php echo e($value->salary); ?></td>
                                <td> <a href="/reg/logo/<?php echo e($value->logo); ?>" type="button" target="_blank">Logo</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.6.1/js/dataTables.buttons.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.6.1/js/buttons.html5.min.js"></script>

<script>
   /* $(document).ready(function() {
        $('#dataTables-example').DataTable({
            responsive: true
        });
    });*/
    $(document).ready(function() {
    $('#example').DataTable( {
        dom: 'Bfrtip',
        buttons: [
            'excelHtml5',
            'csvHtml5',
            'pdfHtml5'
        ],
        "order": [[ 0, "desc" ]]
    } );
} );
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\jobutsob_2023\resources\views/employer/employer_info.blade.php ENDPATH**/ ?>