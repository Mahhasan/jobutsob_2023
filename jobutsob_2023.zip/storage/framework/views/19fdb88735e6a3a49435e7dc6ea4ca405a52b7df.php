<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>Copyright &copy; Job Utsob 2023</span>
        </div>
    </div>
</footer><?php /**PATH F:\jobutsob_2023\resources\views/common/footer.blade.php ENDPATH**/ ?>