

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-8">

            <div class="card" style="box-shadow: 0px 2px #3498db;">
                 <div class="card-header">
                    <div class="row">
                        <div class="col-4">
                            <small class="text-left">
                                <abbr title="Go to Previous page">
                                <a style="text-decoration: none;" href="<?php echo e(route('jobs.index')); ?>">
                                <i class="fa fa-arrow-left"></i> Get Back</a></abbr>
                            </small>
                        </div>
                        <div class="col-4 text-center">
                            Job ID #<?php echo e($job->id); ?> 
                        </div>
                        <div class="col-4 text-right">
                            <form method="POST" action="<?php echo e(route('jobs.destroy',$job->id)); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo e(method_field('DELETE')); ?>

                                <button onclick="return confirm('Are you sure want to delete? ');" style="border:none; background: none;" type="submit" class="text-danger"><i class="fa fa-trash" aria-hidden="true"></i></button>
                                <!-- <div class="form-group">
                                    <input   type="submit" class="btn btn-danger btn btn-sm " value="Delete Job">
                                </div> -->
                            </form>
                        </div>
                    </div>
                </div>


                <div class="card-body">
                    <?php if(session('success')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if($errors->any()): ?>
                      <?php echo implode('', $errors->all('<div class="alert alert-danger">:message</div>')); ?>

                    <?php endif; ?>

                    <form action="<?php echo e(route('jobs.update',$job->id)); ?>" method="POST" enctype="multipart/form-data" >
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="form-group">
                        <label for="title">Job Title:</label>
                        <input type="text" class="form-control" id="title" name="title" required value="<?php echo e($job->title); ?>">
                    </div>


                    <div class="form-group row">
                        <div class="col-sm-6">
                            <label for="company">Company:</label>
                            <input type="text" class="form-control"  disabled value="<?php echo e(\App\Models\Company::find($job->company)->name); ?>">
                        </div>

                        <div class="col-sm-6">
                            <label for="logo">Logo:</label>
                            <img class="img img-responsive" width="100" height="100" src="/logo/<?php echo e($job->logo); ?>" alt="<?php echo e($job->logo); ?>">
                            <input id="logo" type="file" class="form-control" name="logo"  >
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-sm-6">
                            <label for="company">Last Date:</label>
                            <input type="date" class="form-control" id="last_date" name="last_date" required  value="<?php echo e($job->last_date); ?>">
                        </div>

                        <div class="col-sm-6">
                            <label for="salary">Salary:</label>
                            <input type="text" class="form-control" id="salary" name="salary" required  value="<?php echo e($job->salary); ?>">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="job_link">Job Link:</label>
                        <input type="url" name="job_link" class="form-control" id="job_link" value="<?php echo e($job->job_link); ?>">
                    </div>
                    <div class="form-group">
                        <label for="description">Job Description</label>
                        <textarea class="form-control" id="description" name="description" rows="10" ><?php echo $job->description; ?></textarea>
                    </div>
                    
                    <div class="form-group">
                        <label for="short_description">Job Short Description</label>
                        <textarea class="form-control" id="short_description" name="short_description" rows="10" ><?php echo $job->short_description; ?></textarea>
                    </div>
                   
                    <button type="submit" class="btn btn-primary">Update</button>
                    </form>
           

                    
                </div>
            </div>
        </div>
    </div>
</div>
<script src="https://cdn.tiny.cloud/1/wcy885719biomngy7z5xj858nqthf5pg23gqfd8d5nfhze2w/tinymce/5/tinymce.min.js" referrerpolicy="origin"></script>

<script type="text/javascript">
tinymce.init({
    selector: "textarea",
    menubar: false,
    plugins: "link image code",
    toolbar: 'undo redo | styleselect | forecolor | bold italic | alignleft aligncenter alignright alignjustify | outdent indent | link image | code'
});
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\jobutsob_2023\resources\views/jobseeker/job_details.blade.php ENDPATH**/ ?>