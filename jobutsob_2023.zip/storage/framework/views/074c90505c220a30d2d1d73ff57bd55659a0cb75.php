

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card" style="box-shadow: 0px 2px #3498db;">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                        <span class="text-info">Showing Results for:</span> <span class="text-warning">
                        <b><?php echo e(request()->has('q') ? ucfirst(request()->get('q')) : ''); ?> <?php echo e($data->total()); ?> </span></b>
                        </div>
                        <div class="col-md-6 mb-4">
                            <form action="<?php echo e(route('job_search')); ?>" method="GET">
                                <div class="row">
                                    <div class="col-md-5">
                                    <select name="company" id="input" class="form-control">
                                        <option value="0">Select Company</option>
                                        <?php $__currentLoopData = $search_jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($job->company); ?>">
                                                <?php echo e(\App\Models\Company::find($job->company)->name); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>

                                    </div>
                                    <div class="col-md-5">
                                        <input type="text" name="title" class="form-control" placeholder="Search your favorite job">
                                    </div>
                                    <div class="col-md-2">
                                        <button class="btn btn-secondary" type="submit">Search</button>
                                    </div>   
                                </div>   
                            </form>
                        </div>
                    </div>
                    <div class="row">
                        <div class="table-responsive">
                            <table  width="100%" class="table table-striped table-sm table-bordered table-hover" id="jobseeker">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Title</th>
                                        <th>Company Logo</th>
                                        <th>Company Name</th>
                                        <th>Last Date</th>
                                        <th>Details</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr class="odd gradeX" >
                                        <td><?php echo e(++$index); ?></td>
                                        <td><h5 style="color:#2980b9"><b><?php echo e($value->title); ?></b></h5> </td>
                                        <td ><img class="img img-responsive" width="100" 
                                        src="/logo/<?php echo e(\App\Models\Company::find($value->company)->logo); ?>" alt="<?php echo e($value->logo); ?>">
                                        </td>
                                        <td><?php echo e(\App\Models\Company::find($value->company)->name); ?></td>
                                        <td><?php echo e($value->last_date); ?></td>
                                        <td class="text-center"><a 
                                        class="btn  btn-primary"
                                        href="<?php echo e(route('jobs.show',$value->id)); ?>">View & Apply</a></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <h1 class="center m-2" style="color: #bc1d1a !important;">No Job Found</h1>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                            <div class="row p-4">
                            <?php echo e($data->appends(request()->except('page'))->links()); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\jobutsob_2023\resources\views/job_search.blade.php ENDPATH**/ ?>