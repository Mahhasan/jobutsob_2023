

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card" style="box-shadow: 0px 2px #3498db;">
                <div class="card-body">
                    <div class="table-responsive">
                    <p class="text-info">Total Applied Job: <b class="text-warning"><?php echo e($count); ?></b></p>
                        <table  width="100%" class="table table-striped table-sm table-bordered table-hover" id="jobseeker">
                            <thead>
                                <tr>
                                    <th>SL</th>
                                    <th>Job Title & Company</th>
                                    <th>Status</th>
                                    <th>Details</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $my_jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="odd gradeX" >
                                    <td><?php echo e(++$index); ?></td>
                                    <?php if($job = App\Models\Job::find($value->job_id)): ?>
                                        <td><b><?php echo e($job->title); ?></b> at <b><?php echo e($job->com_name->name); ?></b></td>
                                    <?php else: ?>
                                        <td class="text-danger">This Job expired or deleted</td>
                                    <?php endif; ?>
                                    <td><?php echo e($value->status); ?></td>
                                    <td class="text-center">
                                    <abbr title="Click to see job details">
                                        <a class="text-info" href="<?php echo e(route('jobs.show',$value->job_id)); ?>"><i class="fa fa-eye" aria-hidden="true"></i></a></abbr>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\jobutsob_2023\resources\views/my_jobs.blade.php ENDPATH**/ ?>