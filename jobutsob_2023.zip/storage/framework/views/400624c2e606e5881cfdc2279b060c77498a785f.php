
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.3/css/jquery.dataTables.css">


<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-10">

            <div class="card" style="box-shadow: 0px 2px #3498db;">
                <div class="card-header"><b>
                <img src="/logo/<?php echo e(\App\Models\Company::find($job->company)->logo); ?>"
                width="300px"
                alt="a"> <br>
                Job Title:</b> <?php echo e($job->title); ?> <br>
                
                <b>Company: <?php echo e(\App\Models\Company::find($job->company)->name); ?></b><br>

                
                
                <b>Deadline:</b>  <?php echo e($job->last_date); ?><br>
                <a class="btn btn-sm btn-danger" href="<?php echo e(route('companywise_jobs')); ?>">Back To All Jobs</a>
                </div>
                 
              

                <div class="card-body">
                  <b>Job Description:</b> <br>
                  <?php echo $job->description; ?>

           
                    <hr>
                    <?php
                      $x = App\Models\Apply::where('job_id',$job->id)->count();
                    ?>
                    <p><b><?php echo e($x); ?> People applied here</b></p>
                    
                    <a href="<?php echo e(route('download.job.resumes', ['job_id' => $job->id])); ?>" class="btn btn-primary">Download Resumes</a>

                    <div class="table-responsive">
                    <table  width="100%" class="table table-striped table-sm table-bordered table-hover" id="jobseeker">
                        <thead>
                            <tr>
                              
           
                                <th>SL No</th>
                                <th>Name</th>
                                <th>Eamil</th>
                                <th>Mobile No</th>
                                <th>Status</th>
                                <th>Resume</th>
                                <th>Video Resume</th>
                                
                                <th>Bachelor Subject</th>
                                <th>University</th>
                                <th>Year/Semester</th>
                                <th>Result</th>
                                <th>Masters Subject</th>
                                <th>University</th>
                                <th>Year/Semester</th>
                                <th>Result</th>
                              
                            
                            </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="odd gradeX">
                            
                                <td><?php echo e(++$i); ?></td>
                                <?php
                                $user = App\Models\User::where('id',$value->user_id)->first();
                                $jobseeker = App\Models\Jobseeker::where('email',$user->email)->first();
                                ?>
                                <?php if($jobseeker): ?>
                                <td><?php echo e($jobseeker->name); ?></td>
                                <td><?php echo e($user->email); ?></td>
                                <td><?php echo e($jobseeker->cell); ?></td>

                                <td><a href="<?php echo e(route('jobseeker-status',$value->id)); ?>"><?php echo e($value->status); ?></a></td>
                                <td>
                                   
                                    <?php if(isset($value->resume)): ?>
                                    <a href="/resume/<?php echo e($value->resume); ?>" type="button" target="_blank" >Download</a>
                                    <?php else: ?>  
                                    <a href="/resume/<?php echo e($jobseeker->resume); ?>" type="button" target="_blank" >Download.</a>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if(isset($value->video)): ?>
                                    <a href="<?php echo e($value->video); ?>" type="button" target="_blank">Click Here</a>
                                    <?php elseif(isset($value->video)): ?>
                                    <a href="<?php echo e($jobseeker->video); ?>" type="button" target="_blank">Click Here</a>
                                    <?php else: ?>
                                    N/A
                                    <?php endif; ?>
                                </td>


                                
                           
                                </td>

                                <td><?php echo e($jobseeker->bachelor_department->department_name ?? ' '); ?></td>
                                <td><?php echo e($jobseeker->bachelor_institute); ?></td>
                                <td><?php echo e($jobseeker->bachelor_year); ?></td>
                                <td><?php echo e($jobseeker->bachelor_result); ?></td>
                              
                                <td><?php echo e($jobseeker->masters_department->department_name ?? ' '); ?></td>
                                <td><?php echo e($jobseeker->masters_institute); ?></td>
                                <td><?php echo e($jobseeker->masters_year); ?></td>
                                <td><?php echo e($jobseeker->masters_result); ?></td>
                               
                                <?php endif; ?>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  
                    </table>
                    <?php echo e($data->links()); ?>

                    </div>
                    
                </div>
            </div>
        </div>
    </div>
</div>
<script src="https://cdn.tiny.cloud/1/knybwr594mznrv6uagt4lxrf191ll7had91pnu370cyt11gg/tinymce/5/tinymce.min.js" referrerpolicy="origin"></script>

<script type="text/javascript">
tinymce.init({
    selector: "textarea",
    menubar: false,
    plugins: "link image code",
    toolbar: 'undo redo | styleselect | forecolor | bold italic | alignleft aligncenter alignright alignjustify | outdent indent | link image | code'
});
</script>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\jobutsob_2023\resources\views/jobwise_applide.blade.php ENDPATH**/ ?>