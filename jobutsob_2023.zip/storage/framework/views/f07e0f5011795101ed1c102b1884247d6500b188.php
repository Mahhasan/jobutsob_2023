

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-8">


            <div class="card" style="box-shadow: 0px 2px #3498db;">
                <div class="card-header">
                <small class="text-left"><a href="<?php echo e(route('applied', $data->job_id)); ?>" style="text-decoration: none;"><i class="fa fa-arrow-left"></i> Get Back</a></small>
                &nbsp;&nbsp;&nbsp;
                Job Applicant ID #   <?php echo e($data->id); ?>

                </div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <form action="<?php echo e(route('chamgestatus')); ?>" method="POST"  >
                    <?php echo csrf_field(); ?>
                    
                        
                        <input type="hidden" class="form-control" id="id" name="id" value="<?php echo e($data->id); ?>">
                        Current Status: <?php echo e($data->status); ?>

                        <div class="form-group">
                        <label for="status">Update Status:</label>
                        <select class="form-control" id="status" name="status">
                            <option>Initial</option>
                            <option>Written</option>
                            <option>Interview</option>
                            <option>Selected</option>
                            
                        </select>
                        </div>
                    
                   
                   
                   
                    <button type="submit" class="btn btn-primary">Update</button>
                    </form>
           

                

                     

                  
                    
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\jobutsob_2023\resources\views/change.blade.php ENDPATH**/ ?>