

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card" style="box-shadow: 0px 2px #3498db;">
                <div class="card-body">
                    <div class="table-responsive">
                        <div class="card-header" style="display: flex; justify-content: space-between;">
                            <p class="text-info">Total Job: <b class="text-warning"><?php echo e($count); ?></b></p>
                            <p class="text-info">Job list of <b class="text-warning"><?php echo e($company->name); ?></b></p>
                        </div>
                        <table  width="100%" class="table table-striped table-sm table-bordered table-hover" id="jobseeker">
                            <thead>
                                <tr>
                                    <th>SL</th>
                                    <!-- <th>Job ID</th> -->
                                    <th>Job Title</th>
                                    <th>Salary</th>
                                    <th>Last Date</th>
                                    <th>Applied</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="odd gradeX" >
                                    <td><?php echo e(++$index); ?></td>
                                    <!-- <td><?php echo e($value->id); ?></td> -->
                                    <td><?php echo e($value->title); ?></td>
                                    <td><?php echo e($value->salary); ?></td>
                                    <td><?php echo e($value->last_date); ?></td>
                                    <td><a href="<?php echo e(route('jobwise-applide',$value->id)); ?>">Click Here</a>
                                
                                <?php
                                  $x = App\Models\Apply::where('job_id',$value->id)->count();
                                ?>
                                <p><?php echo e($x); ?> applied</p>
                                </td>
                           
                                </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\jobutsob_2023\resources\views/companywise_job.blade.php ENDPATH**/ ?>