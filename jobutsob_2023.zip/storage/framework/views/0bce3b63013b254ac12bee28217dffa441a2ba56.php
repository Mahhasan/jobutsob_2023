

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card" style="box-shadow: 0px 2px #3498db;">
                <div class="card-header">Jobseeker Status</div>

                <div class="card-body">
                    <!-- <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?> -->
                    <div class="table-responsive">
                        <table width="100%" class="table table-striped table-bordered table-hover" id="jobseeker">
                            <thead>
                                <tr>
                                    <th>Sl</th>
                                    <th>Status</th>
                                    <th>Name</th>
                                    <th>Job Title</th>
                                    <th>Company</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="odd gradeX">
                                <td><?php echo e(++$index); ?></td>
                                <td><?php echo e($value->status); ?></td>
                                <td><?php echo e($value->user->name); ?></td>
                                <td>
                                    <?php if($value->job): ?>
                                        <?php echo e($value->job->title); ?>

                                    <?php else: ?>
                                        N/A
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($value->job && $value->job->com_name): ?>
                                        <?php echo e($value->job->com_name->name); ?>

                                    <?php else: ?>
                                        N/A
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\jobutsob_2023\resources\views/view_jobseeker_status.blade.php ENDPATH**/ ?>