

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card" style="box-shadow: 0px 2px #3498db;">
                <div class="card-header">Job Applicant ID #   <?php echo e($data->id); ?>

                <a class="btn btn-sm btn-danger" href="<?php echo e(route('jobwise-applide', $data->job_id)); ?>">Back</a>
                </div>
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <form action="<?php echo e(route('update-jobseeker-status')); ?>" method="POST"  >
                    <?php echo csrf_field(); ?>
                        <input type="hidden" class="form-control" id="id" name="id" value="<?php echo e($data->id); ?>">
                        <div class="form-group">
                        <label for="status">Select Status: Current: <?php echo e($data->status); ?></label>
                        <select class="form-control" id="status" name="status">
                            <option>Initial</option>
                            <option>Interview</option>
                            <option>Written</option>
                            <option>Viva</option>
                            <option>Selected</option>
                            <option>Rejected</option>
                        </select>
                        </div>
                    <button type="submit" class="btn btn-primary">Update</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\jobutsob_2023\resources\views/jobseeker_status.blade.php ENDPATH**/ ?>