

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-8">
                    <?php if(session('success')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if(session('warning')): ?>
                        <div class="alert alert-danger" role="alert">
                            <?php echo e(session('warning')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if($errors->any()): ?>
                      <?php echo implode('', $errors->all('<div class="alert alert-danger">:message</div>')); ?>

                    <?php endif; ?>
            <div class="card" style="box-shadow: 0px 2px #3498db;">
                <div class="card-header">
                    <small class="text-left">
                        <abbr title="Go to Previous page">
                            <a style="text-decoration: none;" href="<?php echo e(URL::previous()); ?>">
                            <i class="fa fa-arrow-left"></i> Get Back</a></abbr></small>
                
            
                
            </div>
                
                <!-- <hr style="border-color: #449fdc;"> -->
                

                <div class="card-body">
                   
                 

                    <p><b>Job Title: </b><span style="color:#2980b9; font-size: 18px;"><b><?php echo e($job->title); ?></b></span> </p>
                    <p><b>Deadline: <?php echo e($job->last_date); ?></b></p>
                    <p><b>Salary: <?php echo e($job->salary); ?></b></p>
                    <p><b>Company: </b><?php echo e(\App\Models\Company::find($job->company)->name); ?></p>
                    <p><img src="/logo/<?php echo e($job->logo); ?>" alt="" class="img img-responsive" width="150px"></p>
                    <p><b>Job Description: </b></p>
                    <?php echo $job->description; ?>

                    <!--<a class="btn btn-danger" href="<?php echo e(route('alljobs')); ?>">Back To All Jobs</a>-->
                    <hr style="border-color: #449fdc;">
                    
                   
                    <?php if(!$isapplied): ?>
                    <a class="btn btn-primary" href="<?php echo e(route('applynow',$job->id)); ?>">Apply Now</a>
                    <?php else: ?> 
                    <button class="btn btn-success" href="#" disabled> Already Applied</button>
                    <?php endif; ?>

                </div>
            </div>
        </div>
    </div>
</div>
<script src="https://cdn.tiny.cloud/1/knybwr594mznrv6uagt4lxrf191ll7had91pnu370cyt11gg/tinymce/5/tinymce.min.js" referrerpolicy="origin"></script>

<script type="text/javascript">
tinymce.init({
    selector: "textarea",
    menubar: false,
    plugins: "link image code",
    toolbar: 'undo redo | styleselect | forecolor | bold italic | alignleft aligncenter alignright alignjustify | outdent indent | link image | code'
});
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\jobutsob_2023\resources\views/apply.blade.php ENDPATH**/ ?>