

<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-10">
            
            <div class="card" style="box-shadow: 0px 2px #3498db;">
                <div class="card-header">
                    <div class="row">
                        <div class="col-4">
                            <small class="text-left">
                                <abbr title="Go to Previous page">
                                    <a style="text-decoration: none;" href="<?php echo e(route('jobs.index')); ?>">
                                    <i class="fa fa-arrow-left"></i> Get Back</a></abbr></small>
                                    &nbsp; &nbsp;Job ID #<?php echo e($job->id); ?> 
                        </div>
                        <div class="col-7">
                            <?php echo e($job->title); ?> 
                        </div>
                        <div class="col-1 text-right">
                        <abbr title="Edit this job"><a class="text-info" href="<?php echo e(route('jobs.edit',$job->id)); ?>" class=""><i class="fa fa-edit" aria-hidden="true"></i></a></abbr>
                        </div>
                    </div>
                </div>
                
                <div class="card-body">
                <div class="row">
            <div class="col-md-4">
                <img id="blah" src="/logo/<?php echo e(\App\Models\Company::find($job->company)->logo); ?>" width= 80%; class="rounded" alt="your image" />
                <div class="mt-3">
                    <i class="far fa-building" aria-hidden="true"></i>
                    <?php echo e(\App\Models\Company::find($job->company)->name); ?>

                </div>
                <div class="mt-2">
                    <strong><i class="fas fa-money-bill-alt"></i> &nbsp; Salary:</strong> &#2547; <?php echo e($job->salary); ?>

                </div>
                <div class="mt-2">
                    <strong><i class="fa fa-calendar" aria-hidden="true"></i>&nbsp;Last Date:</strong>  <?php echo e($job->last_date); ?>

                </div>
                <!-- <a href="" class="btn btn-outline-primary btn-sm btn-block">Get Register</a> -->
            </div>
            <div class="col-md-8 text-left">
                <div class="mb-3">
                    <strong>Short Description:</strong> <?php echo $job->short_description; ?>

                </div>
                <div class="mb-3">
                    <strong>Description:</strong> <?php echo $job->description; ?>

                </div>
                <!-- <a href="" class="btn btn-primary">Edit</a>
                <form action="" method="POST" style="display: inline-block;">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger">Delete</button>
                </form>   -->
            </div>
        </div><br>
                    <hr>

                    <div class="table-responsive">
                        <p class="text-right"><abbr title="Download all Resume"><a href="<?php echo e(route('download.job.resumes', ['job_id' => $job->id])); ?>" class="text-info">
                            <i class="fa fa-download" aria-hidden="true"></i></a></abbr></p>
                        <table  width="100%" class="table table-striped table-sm table-bordered table-hover" id="jobseeker">
                            <thead>
                                <tr class="text-center">
                                    <th>SL</th>
                                    <th>Name</th>
                                    <th>Eamil</th>
                                    <th>Mobile No.</th>
                                    <th>Bachelor Info</th>
                                    <!-- <th>University</th>
                                    <th>Passing Year/Semester</th>
                                    <th>Bachelor Result</th> -->
                                    <th>Masters Info</th>
                                    <!-- <th>University</th>
                                    <th>Passing Year/Semester</th>
                                    <th>Bachelor Result</th> -->
                                    <th>Status</th>
                                    <th>Resume</th>
                                    <th>Details</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="odd gradeX">
                                    <td><?php echo e(++$index); ?></td>
                                    <?php
                                        $user = App\Models\User::where('id',$value->user_id)->first();
                                        $jobseeker = App\Models\Jobseeker::where('email',$user->email)->first();
                                    ?>
                                    <?php if($jobseeker): ?>
                                    <td><?php echo e($jobseeker->name); ?></td>
                                    <td><?php echo e($user->email); ?></td>
                                    <td><?php echo e($jobseeker->cell); ?></td>
                                    <td>
                                        <abbr title="<?php echo e($jobseeker->name); ?>'s Bachelor information &#013;<?php echo e($jobseeker->bachelor_faculty->faculty_name ?? ' '); ?>&#013;<?php echo e($jobseeker->bachelor_department->department_name ?? ' '); ?>&#013;Bachelor Status: <?php echo e($jobseeker->bachelor_status); ?>&#013;Result: <?php echo e($jobseeker->bachelor_result); ?>&#013;Passing Year: <?php echo e($jobseeker->bachelor_year); ?>&#013;Institute: <?php echo e($jobseeker->bachelor_institute); ?>">
                                        <?php echo e($jobseeker->bachelor_department->department_name ?? ' '); ?></abbr></td>
                                    <td>
                                        <abbr title="<?php echo e($jobseeker->name); ?>'s masters information &#013;<?php echo e($jobseeker->masters_faculty->faculty_name ?? ' '); ?>&#013;<?php echo e($jobseeker->masters_department->department_name ?? ' '); ?>&#013;Bachelor Status: <?php echo e($jobseeker->masters_status); ?>&#013;Result: <?php echo e($jobseeker->masters_result); ?>&#013;Passing Year: <?php echo e($jobseeker->masters_year); ?>&#013;Institute: <?php echo e($jobseeker->masters_institute); ?>">
                                        <?php echo e($jobseeker->masters_department->department_name ?? ' '); ?></abbr></td>
                                    
                                    <td>
                                        <abbr title="Update <?php echo e($jobseeker->name); ?>'s status">
                                        <a style="text-decoration: none;" href="<?php echo e(route('change',$value->id)); ?>" class="text-info"><?php echo e($value->status); ?> 
                                        <i class="fa fa-edit" aria-hidden="true"></i></a></abbr>
                                    </td>
                                    <td class="text-center"><abbr title="Download <?php echo e($jobseeker->name); ?>'s resume">
                                        <?php if(isset($value->resume)): ?>
                                        <a href="/resume/<?php echo e($value->resume); ?>" type="button" class="text-info" target="_blank"><i class="fa fa-download" aria-hidden="true"></i></a>
                                        <?php else: ?>  
                                        <a href="/resume/<?php echo e($jobseeker->resume); ?>" type="button" class="text-info" target="_blank"><i class="fa fa-download" aria-hidden="true"></i></a>
                                        <?php endif; ?></abbr>
                                        &nbsp; &nbsp;
                                        <abbr title="click to see <?php echo e($jobseeker->name); ?>'s video resume">
                                        <?php if(isset($value->video)): ?>
                                        <a href="<?php echo e($value->video); ?>" type="button" target="_blank"><i class="fa fa-link" aria-hidden="true"></i></a>
                                        <?php else: ?>
                                        <a href="<?php echo e($jobseeker->video); ?>" type="button" target="_blank"><i class="fa fa-link" aria-hidden="true"></i></a>
                                        <?php endif; ?></abbr>
                                    </td>
                                    <td class="text-center">
                                        <abbr title="click to see <?php echo e($jobseeker->name); ?>'s full information">
                                        <a class="text-info" href="" data-toggle="modal" data-target="#JobseekerDetails<?php echo e($value->id); ?>"><i class="fa fa-eye" aria-hidden="true"></i></a>
                                        </abbr></td>
                                    <?php endif; ?>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Modal -->
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="JobseekerDetails<?php echo e($value->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <?php if($jobseeker): ?>
            <div class="modal-header" style="border-bottom: 2px solid #3490dc;">
                <h5 class="modal-title" style="color: #3490dc;" id="exampleModalLabel"><b><?php echo e($jobseeker->name); ?>'s Details</b></h5><br>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <p class="card-title">Name:<b> <?php echo e($jobseeker->name); ?></b></p>
                <p class="card-text">Email: <?php echo e($user->email); ?></p>
                <p class="card-text">Mobile: <?php echo e($jobseeker->cell); ?></p>

                <p class="card-text">Bachelor Information: </p>
                    <p class="pl-5" style="font-size: 14px">
                    <?php echo e($jobseeker->bachelor_faculty->faculty_name ?? ' '); ?><br>
                    <?php echo e($jobseeker->bachelor_department->department_name ?? ' '); ?> <br>
                    Bachelor Status: <?php echo e($jobseeker->bachelor_status); ?> <br>
                    Result: <?php echo e($jobseeker->bachelor_result); ?> <br>
                    Passing Year/Semester: <?php echo e($jobseeker->bachelor_year); ?> <br>
                    Institute: <?php echo e($jobseeker->bachelor_institute); ?></p>

                <p class="card-text">Masters Information: </p>
                    <p class="pl-5" style="font-size: 14px">
                    <?php echo e($jobseeker->masters_faculty->faculty_name ?? ' '); ?><br>
                    <?php echo e($jobseeker->masters_department->department_name ?? ' '); ?> <br>
                    Bachelor Status: <?php echo e($jobseeker->masters_status); ?> <br>
                    Result: <?php echo e($jobseeker->masters_result); ?> <br>
                    Passing Year/Semester: <?php echo e($jobseeker->masters_year); ?> <br>
                    Institute: <?php echo e($jobseeker->masters_institute); ?></p>

                <p class="card-text">Experience: <?php echo e($jobseeker->experience); ?> years</p>
                <p class="card-text">Video Resume: 
                    <abbr title="click to see <?php echo e($jobseeker->name); ?>'s video resume">
                    <?php if(isset($value->video)): ?>
                    <a href="<?php echo e($value->video); ?>" type="button" target="_blank"><i class="fa fa-link" aria-hidden="true"></i>&nbsp;<?php echo e($jobseeker->video); ?></a>
                    <?php else: ?>
                    <a href="<?php echo e($jobseeker->video); ?>" type="button" target="_blank"><i class="fa fa-link" aria-hidden="true"></i>&nbsp;<?php echo e($jobseeker->video); ?></a>
                    <?php endif; ?></abbr>
                </p>
                <p class="card-text">Resume: 
                    <abbr title="Download <?php echo e($jobseeker->name); ?>'s resume">
                    <?php if(isset($value->resume)): ?>
                    <a href="/resume/<?php echo e($value->resume); ?>" type="button" class="text-info" target="_blank"><i class="fa fa-download" aria-hidden="true"></i>&nbsp;Resume</a>
                    <?php else: ?>  
                    <a href="/resume/<?php echo e($jobseeker->resume); ?>" type="button" class="text-info" target="_blank"><i class="fa fa-download" aria-hidden="true"></i>&nbsp;Resume</a>
                    <?php endif; ?></abbr></p>
                <p class="card-text">Address: <?php echo e($jobseeker->address); ?></p>
                <p class="card-text">Skills: <?php echo e($jobseeker->skill); ?></p>
                <p class="card-text">Preferred Industry: <?php echo e($jobseeker->industry); ?></p>
            </div>
            <div class="modal-footer" style="border-top: 1px solid rgb(52, 144, 220);">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>  
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<script src="https://cdn.tiny.cloud/1/knybwr594mznrv6uagt4lxrf191ll7had91pnu370cyt11gg/tinymce/5/tinymce.min.js" referrerpolicy="origin"></script>

<script type="text/javascript">
tinymce.init({
    selector: "textarea",
    menubar: false,
    plugins: "link image code",
    toolbar: 'undo redo | styleselect | forecolor | bold italic | alignleft aligncenter alignright alignjustify | outdent indent | link image | code'
});
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\jobutsob_2023\resources\views/applied.blade.php ENDPATH**/ ?>