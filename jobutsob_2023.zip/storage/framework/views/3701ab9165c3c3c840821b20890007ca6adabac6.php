

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-8">


            <div class="card" style="box-shadow: 0px 2px #3498db;">
                <div class="card-header">
                <small class="text-left">
                    <abbr title="Go to Previous page">
                        <a style="text-decoration: none;" href="<?php echo e(route('jobseekers')); ?>">
                        <i class="fa fa-arrow-left"></i> Get Back</a></abbr></small>    
                        &nbsp; &nbsp; Job Seeker ID #   <?php echo e($data->id); ?>

                </div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <form action="<?php echo e(route('approvepayment')); ?>" method="POST"  >
                    <?php echo csrf_field(); ?>
                    
                        
                        <input type="hidden" class="form-control" id="id" name="id" value="<?php echo e($data->id); ?>">

                        <p>TRIX ID:  <?php echo e($data->trix); ?></p>

                        <div class="form-group">
                        <label for="status">Select Payment Status: 
                            
                           
                        </label>
                        <select class="form-control" id="status" name="payment_status">
                            <option value="2"<?php echo $data->payment_status==2?'selected' : ''?>>Pending</option>
                            <option value="0"<?php echo $data->payment_status==0?'selected' : ''?>>Unpaid</option>
                            <option value="1"<?php echo $data->payment_status==1?'selected' : ''?>>Paid</option>
                    
                            
                        </select>
                        </div>
                    
                   
                   
                   
                    <button type="submit" class="btn btn-primary">Update</button>
                    </form>
           

                

                     

                  
                    
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\jobutsob_2023\resources\views/approve.blade.php ENDPATH**/ ?>